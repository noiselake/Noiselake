import { login } from "../util/screens.js";

const output = "Logging out...";

export { output };
export default () => login();
