const output = [
	"I would tell you a UDP joke...",
	" ",
	"...but you might not get it"
];

export { output };
