/** Clear the terminal screen */
function clear() {
	let terminal = document.querySelector(".terminal");
	terminal.innerHTML = "";
}

export default clear;
