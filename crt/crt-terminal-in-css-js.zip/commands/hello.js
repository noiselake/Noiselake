const output = "Good day.";

export { output };
