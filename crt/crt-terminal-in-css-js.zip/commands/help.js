const output = [
	"Available commands:",
	"help, brogue, hackerman, matrix, cowsay, clear, logout, reboot, quit"
];

export { output };
